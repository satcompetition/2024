#include "TimeSlotMapping.h"

const int DoubleEndedTimePointManager::FROM_BEGIN = 0;
const int DoubleEndedTimePointManager::FROM_END = 1;